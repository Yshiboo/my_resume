package uk.ac.ed.inf.cache;

import uk.ac.ed.inf.path.FlightPath;
import uk.ac.ed.inf.ilp.data.LngLat;
import uk.ac.ed.inf.ilp.data.Restaurant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * The file is used for storing the generated path.
 * The Drone path is used for the drone geojson file.
 * The FlightPath is used for the filghtpath file.
 */
public class FlightPathCache {
	private Map<Restaurant, ArrayList<LngLat>> cacheForDronePath;
	private  Map<Restaurant, FlightPath[]> cacheForFlightPath;

	public FlightPathCache() {
		this.cacheForDronePath = new HashMap<>();
		this.cacheForFlightPath = new HashMap<>();
	}

	public ArrayList<LngLat> getDronePath(Restaurant restaurant) {
		// Check if the flight path is in the cache
		if (cacheForDronePath.containsKey(restaurant)) {
			return cacheForDronePath.get(restaurant);
		}else{
			return null;
		}
	}

	public  FlightPath[] getFlightPath(Restaurant restaurant){
		if(cacheForFlightPath.containsKey(restaurant)){
			return cacheForFlightPath.get(restaurant);

		}else {
			return null;
		}

	}

	public void setCacheForFlightPath(Restaurant restaurant,FlightPath[] flightPaths){
		cacheForFlightPath.put(restaurant,flightPaths);
	}

	public void setDronePath(Restaurant restaurant, ArrayList<LngLat> flightPath) {
		cacheForDronePath.put(restaurant, flightPath);

	}
}

