package uk.ac.ed.inf;

import uk.ac.ed.inf.cache.FlightPathCache;
import uk.ac.ed.inf.restservice.RestService;
import uk.ac.ed.inf.ilp.constant.OrderStatus;
import uk.ac.ed.inf.ilp.data.LngLat;
import uk.ac.ed.inf.ilp.data.Order;
import uk.ac.ed.inf.ilp.data.Restaurant;
import uk.ac.ed.inf.order.ValidateOrders;
import uk.ac.ed.inf.path.FlightPath;
import uk.ac.ed.inf.path.PathFinding;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.*;

/**
 * The class is used for the whole system from fetching the order to generating the files.
 * @create 2023-10-19-19:21
 */
public class PizzaDelivery {
		public static void main(String[] args) {
			// start time
			long stime = System.currentTimeMillis();

			if (args.length < 2) {
				System.err.println("the date of the order and the base URL need to be provided");
				throw new IllegalArgumentException("The input needs to be the date and the base URL.");
			}

			/* Get the date and check it. */
			String dateString = args[0];
			checkDate(dateString);

			/* Get the web link and check it*/
			String baseUrl = args[1];
			boolean validURL = checkURL(baseUrl);
			if (!validURL) {
				System.err.println("The URL provided is not as required.");
				throw new IllegalArgumentException("The input for the URL is invalid.");
			}

			System.out.println("Inputs are verified.");

			/* Verify orders. */
			// Use validateOrders class to validate order from rest service.
			ValidateOrders validateOrders = new ValidateOrders(baseUrl);
			verifyOrders(validateOrders, dateString);

			// Get all the valid orders.
			ArrayList<Order> validOrders = validateOrders.getValidOrders();

			// Get all the orders.
			ArrayList<Order> orders = validateOrders.getAllOrders();

			System.out.println("Orders are verified.");

			/* Find path. */
			// Create the PathFinding object in order to find the path.
			PathFinding pathFinding = new PathFinding(validateOrders, baseUrl);

			// Use for the drone file for all valid orders.
			ArrayList<ArrayList> flightpathForAllOrders = new ArrayList<>();
			// Use for the flightpath file for all valid orders.
			ArrayList<FlightPath> flightpathForAll = new ArrayList<>();

			findPath(pathFinding,validOrders,flightpathForAllOrders,flightpathForAll);

			System.out.println("Paths are found.");


			/* Generate outfile */
			generateFiles(orders,dateString,flightpathForAll,flightpathForAllOrders);
			System.out.println("The programme is successively running over");

			// End time.
			long etime = System.currentTimeMillis();
			// Calculate the execution time.
			System.out.printf("Execution time: %d ms.\n", (etime - stime));
		}

	private static boolean checkURL(String baseUrl) {
		try {
			URL url = new URL(baseUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			int responseCode = conn.getResponseCode();
			conn.disconnect();
			return responseCode == HttpURLConnection.HTTP_OK;
		} catch (Exception e) {
			System.err.println("Error validating URL: " + e.getMessage());
			return false;
		}
	}

	private static void checkDate(String dateString){
		// The services launches on 1st January 2023.
		String specifiedDay = "2023-01-01";
		LocalDate serviceLaunched = LocalDate.parse(specifiedDay);

		// Get the order date
		LocalDate orderDate = null;
		try {
			orderDate = LocalDate.parse(dateString);
		} catch (Exception e) {
			System.err.println("The date (YYYY-MM-DD) is invalid: " + dateString);
			throw new DateTimeException("The date is invalid: " + dateString);
		}

		// check whether the date is valid.
		boolean launchDay = orderDate.isEqual(serviceLaunched);
		boolean validDate = orderDate.isAfter(serviceLaunched);
		if (!validDate && !launchDay) {
			System.err.println("The rest service is begun from 2023-01-01.");
		}

	}

	private static void verifyOrders(ValidateOrders validateOrders,String dateString) {
		// Get all the orders of a specified day from the rest service.
		Order[] ordersFromRestService = validateOrders.orderForSpecifiedDateFromRS(dateString);
		// Iterate over all the orders.
		for (Order order : ordersFromRestService) {
			// Check whether the order is valid.
			validateOrders.checkValidation(order);
		}
	}

	private static void findPath(PathFinding pathFinding,ArrayList<Order> validOrders,ArrayList<ArrayList> flightpathForAllOrders,ArrayList<FlightPath> flightpathForAll) {
		// Initialise the relevant location. i.e. the restaurant, the central area and the no-fly regions
		pathFinding.initialize();

		// Establish the comparator for the priority queue utilized in the A* search algorithm.
		pathFinding.comparatorForAlgorithm();

		// Create the FlightPathCache object for quick access to the generated path.
		FlightPathCache flightPath = new FlightPathCache();

		// Record target restaurants of every valid order.
		Restaurant targetRestaurant;

		// Record the flightpath to the target restaurant.
		ArrayList<LngLat> flightPathToTargetRestaurant;

		// Iterate over valid orders to generate the flightpath of the drone.
		for (int i = 0; i < validOrders.size(); i++) {//validOrders.size()
			// Create FlightPath[] object to record the flightpath of one order.
			FlightPath[] flightPaths;

			// Record the flightpath from AT to the target restaurant of every order.
			ArrayList<LngLat> singleFlightpathPoints;

			// Get the target restaurant.
			targetRestaurant = pathFinding.targetRestaurant(i);

			// Get the flightpath.
			flightPathToTargetRestaurant = flightPath.getDronePath(targetRestaurant);
			// Check whether the flightpath has already been generated. If not,
			if (flightPathToTargetRestaurant == null) {
				// use A star algorithm to find the path.
				singleFlightpathPoints = pathFinding.aStar(i);

				// Add the flightpath in the cache.
				flightPath.setDronePath(targetRestaurant, new ArrayList<>(singleFlightpathPoints));
			} else {
				// If the flightpath has already been generated, assign the value getting from the cache to the variable.
				singleFlightpathPoints = flightPathToTargetRestaurant;
			}
			// Record the path to the target restaurant.
			FlightPath[] path = flightPath.getFlightPath(targetRestaurant);
			// Check whether the path has already been generated. If not,
			if (path == null) {
				// Find the path.
				flightPaths = pathFinding.flightPaths(i);

				// Add the path in the cache.
				Collections.addAll(flightpathForAll, flightPaths);
				flightPath.setCacheForFlightPath(targetRestaurant, flightPaths);
			} else {
				// If the path has already been generated, assign the value getting from the cache to the variable,
				// except for the order number.
				flightPaths = new FlightPath[path.length];

				// Iterate over the path to reset the order number.
				for (int j = 0; j < path.length; j++) {
					flightPaths[j] = new FlightPath(path[j]);
					flightPaths[j].setOrderNo(validOrders.get(i).getOrderNo());
					// Add the generated new order number flightpath to the flightpathForAll.
					flightpathForAll.add(flightPaths[j]);
				}
			}

			// Add the single path to the flight path.
			flightpathForAllOrders.add(new ArrayList<>(singleFlightpathPoints));

			// Set the status of valid generated-path orders to be delivered.
			validOrders.get(i).setOrderStatus(OrderStatus.DELIVERED);
		}

	}

	private static void generateFiles(ArrayList<Order> orders,String dateString,ArrayList<FlightPath> flightpathForAll,ArrayList<ArrayList> flightpathForAllOrders) {
		// Put the resulting files in the directory resultfiles.
		Path path = Paths.get("resultfiles");
		// Check whether the directory exists.
		if (!Files.exists(path)) {
			try {
				Files.createDirectories(path);
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		// Create the RestService object in order to generate outfile.
		RestService restService = new RestService();

		if(orders.size() == 0){
			System.out.println("There is no order generated.");
		}

		// Generate the outfile for all valid orders.
		restService.WriteToJson(orders, dateString);

		if(flightpathForAll.size() == 0){
			System.out.println("There is no path generated.");
		}

		// Generate the outfile for Flightpath of the drone.
		restService.WriteToJsonLng(flightpathForAll, dateString);

		// Generate the GEOjson outfile.
		restService.writeToGeoJson(flightpathForAllOrders, dateString);

	}
}
