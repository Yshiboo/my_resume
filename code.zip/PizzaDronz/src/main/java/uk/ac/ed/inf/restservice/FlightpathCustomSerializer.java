package uk.ac.ed.inf.restservice;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import uk.ac.ed.inf.path.FlightPath;

import java.io.IOException;

/**
 * The class is used for the serializer of the FlightPath.
 * @create 2023-11-03-23:18
 */
public class FlightpathCustomSerializer extends StdSerializer<FlightPath>{
	private static final long serialVersionUID = 1L;


	public FlightpathCustomSerializer() {
		this(null);
	}

	public FlightpathCustomSerializer(Class clazz) {
		super(clazz);
	}



	@Override
	public void serialize(FlightPath flightpath, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
		jsonGenerator.writeStartObject();
		jsonGenerator.writeStringField("orderNo",flightpath.getOrderNo());
		jsonGenerator.writeObjectField("fromLongitude",flightpath.getFromLongitude());
		jsonGenerator.writeObjectField("fromLatitude",flightpath.getFromLatitude());
		jsonGenerator.writeNumberField("angle",flightpath.getAngle());
		jsonGenerator.writeObjectField("toLongitude",flightpath.getToLongitude());
		jsonGenerator.writeObjectField("toLatitude",flightpath.getToLatitude());
		jsonGenerator.writeEndObject();
	}
}
