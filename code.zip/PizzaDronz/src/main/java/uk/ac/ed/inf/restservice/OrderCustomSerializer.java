package uk.ac.ed.inf.restservice;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import uk.ac.ed.inf.ilp.data.Order;

import java.io.IOException;

/**
 * The class is used for the serializer of the Order.
 * @create 2023-10-31-20:27
 */
public class OrderCustomSerializer extends StdSerializer<Order> {
	private static final long serialVersionUID = 1L;


	public OrderCustomSerializer() {
		this(null);
	}

	public OrderCustomSerializer(Class clazz) {
		super(clazz);
	}


	@Override
	public void serialize(Order order, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
		jsonGenerator.writeStartObject();
		jsonGenerator.writeStringField("orderNo",order.getOrderNo());
		jsonGenerator.writeObjectField("orderStatus",order.getOrderStatus());
		jsonGenerator.writeObjectField("orderValidationCode",order.getOrderValidationCode());
		jsonGenerator.writeNumberField("costInPence",order.getPriceTotalInPence());
		jsonGenerator.writeEndObject();
	}
}
