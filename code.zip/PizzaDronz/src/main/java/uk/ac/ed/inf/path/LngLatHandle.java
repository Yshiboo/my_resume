package uk.ac.ed.inf.path;

import uk.ac.ed.inf.ilp.constant.SystemConstants;
import uk.ac.ed.inf.ilp.data.LngLat;
import uk.ac.ed.inf.ilp.data.NamedRegion;
import uk.ac.ed.inf.ilp.interfaces.LngLatHandling;

import java.awt.geom.Path2D;
import java.math.BigDecimal;


/**
 * The class is used to implement LngLatHandling interface to provide methods for handling the point.
 * @create 2023-09-29-1:42
 */

public class LngLatHandle implements LngLatHandling {
	/**
	 * To calculate the distance from the starting position to the destination
	 *
	 * @param startPosition the starting position
	 * @param endPosition  destination
	 * @return the distance value
	 */
	@Override
	public double distanceTo(LngLat startPosition, LngLat endPosition) {
		// The latitude of the starting point measured in degrees
		double startLat = startPosition.lat();

		// The longitude of the starting point measured in degrees
		double startLng = startPosition.lng();

		// The latitude of the destination measured in degrees
		double desLat = endPosition.lat();

		// The longitude of the destination measured in degrees
		double desLng = endPosition.lng();

		// Calculate distances between the starting point and destination using the Pythagorean Theorem.
		return Math.sqrt(Math.pow(startLat-desLat,2)+Math.pow(startLng-desLng,2));
	}

	/**
	 *  Verify whether drone flies close to the position.
	 *
	 * @param startPosition Current location of the drone
	 * @param otherPosition Target location of the drone
	 * @return true if done is close to the target location otherwise false
	 */
	@Override
	public boolean isCloseTo(LngLat startPosition, LngLat otherPosition) {
		// the distance between the current location of the drone and the target location
		double dis;

		// The latitude of the current location measured in degrees
		double startLat = startPosition.lat();

		// The longitude of the current location measured in degrees
		double startLng = startPosition.lng();

		// The latitude of the target location measured in degrees
		double otherLat = otherPosition.lat();

		// The longitude of the target location measured in degrees
		double otherLng = otherPosition.lng();

		// Calculate distances between the target location and the current location using the Pythagorean Theorem.
		dis = Math.sqrt(Math.pow(startLat-otherLat,2)+Math.pow(startLng-otherLng,2));

		// Determine whether done is close to the target location.
		boolean res = dis < SystemConstants.DRONE_IS_CLOSE_DISTANCE;
		return res;
	}

	@Override
	public boolean isInRegion(LngLat position, NamedRegion region) {
		// The latitude of the position measured in degrees
		double lat = position.lat();

		// The longitude of the position measured in degrees
		double lng = position.lng();;

		// The boundary of the region
		LngLat[] vertices = region.vertices();

		//Check whether the point is on the border
		boolean isOnBoundaryOrBetweenSeg = false;

		// Define a polygon
		Path2D.Double polygon = new Path2D.Double();

		// Move the starting point to the first vertex of the polygon
		polygon.moveTo(vertices[0].lng(),vertices[0].lat());

		//Iterate over the remaining vertices
		for(int k = 1;k<vertices.length;k++) {
			polygon.lineTo(vertices[k].lng(), vertices[k].lat());
			// Check whether the position point is on one of the borders
			if(isOnLine(position,vertices[k-1],vertices[k])){
				isOnBoundaryOrBetweenSeg = true;
			}
		}

		// Close path
		polygon.closePath();

		// Check whether the position point is in the area
		boolean isInArea = polygon.contains(lng, lat);

		boolean isInRegion = isInArea || isOnBoundaryOrBetweenSeg;

		return isInRegion;
	}

	@Override
	public LngLat nextPosition(LngLat startPosition, double angle) {
		// The variable result is used to check whether the angle is one of 16 major compass directions
		double result = angle / 22.5;

		// The angle is invalid, or the angle is not one of the 16 major compass directions or the angle doesn't represent that the drone is hovering
		if (result < 0 || ((result != Math.floor(result) || angle>360) && angle != 999)){
			throw new IllegalArgumentException("This angle is invalid.");
		}

		// The latitude of the starting position measured in degrees
		double lat = startPosition.lat();
		// The longitude of the starting position measured in degrees
		double lng = startPosition.lng();

		// Convert angle to radians
		double radians = Math.toRadians(angle);

		// Calculate the next position
		LngLat nextP;
		if(angle == 999){
			// The drone is hovering
			nextP = startPosition;
		}else{
			nextP = new LngLat(lng+SystemConstants.DRONE_MOVE_DISTANCE*Math.cos(radians),
					lat+SystemConstants.DRONE_MOVE_DISTANCE*Math.sin(radians));
		}

		// Return the next position
		return nextP;
	}

	private boolean isPointOnLine(LngLat point, LngLat p1, LngLat p2) {
		double ax = point.lng();
		double ay = point.lat();

		double bx = p1.lng();
		double by = p1.lat();

		double cx = p2.lng();
		double cy = p2.lat();

		// calculate distances
		double distAB = Math.sqrt(Math.pow(ax - bx, 2) + Math.pow(ay - by, 2));
		double distAC = Math.sqrt(Math.pow(ax - cx, 2) + Math.pow(ay - cy, 2));
		double distBC = Math.sqrt(Math.pow(bx - cx, 2) + Math.pow(by - cy, 2));

		// compare distances with a small tolerance
		return Math.abs(distAB - (distAC + distBC)) < 0.00001;
	}

	/**
	 * Verify whether a point is on the border
	 * @param position the position point
	 * @param p1 the boundary edge
	 * @param p2 the other boundary edge
	 * @return
	 */
	private boolean isOnLine(LngLat position,LngLat p1,LngLat p2){
		double a = position.lng();
		double b = position.lat();
		double x1 = p1.lng();
		double y1 = p1.lat();
		double x2 = p2.lng();
		double y2 = p2.lat();
		// Record boolean value
		boolean bl = false;
		// Distinguish whether p1 and p2 are the same point
		if(x1==x2){
			if(x2==a){
				if(y1==y2){

					if(y2==b){
						return true;
					}
					return false;
				}
			}
			return false;
		}
		// p is the slope of the two points
		double p = (y2-y1)/(x2-x1);
		if(p<=0){
			// 1. p2 -- x -- p1 and descending lines, so p2y>xy>p1y
			if(x1>x2){
				if(a>=x2 && a<=x1 && b>=y1 && b<=y2){

					bl = isPointOnLine(position,p1,p2);
				}
				// 2. p1 -- x -- p2 and descending lines, so p1y>xy>p2y
			}else{
				if(a>=x1 && a<=x2 && b>=y2 && b<=y1){
					isPointOnLine(position,p1,p2);
					bl = isPointOnLine(position,p1,p2);
				}
			}
		}else{
			// 3. p2 -- x -- p1 and increasing line. so p2y<xy<p1y
			if(x1>x2){
				if(y1>y2){
					if(a>=x2 && a<=x1 && b>=y2 && b<=y1){
						isPointOnLine(position,p1,p2);
						bl = isPointOnLine(position,p1,p2);
					}
				}
				// 4. p1 -- x -- p2 and increasing line. so p1y<b<p2y
			}else{
				if(a>=x1 && a<=x2 && b>=y1 && b<=y2){
					isPointOnLine(position,p1,p2);
					bl = isPointOnLine(position,p1,p2);
				}
			}
		}
		return bl;
	}



}
