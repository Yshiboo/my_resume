package uk.ac.ed.inf.restservice;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import uk.ac.ed.inf.ilp.data.LngLat;
import uk.ac.ed.inf.ilp.data.NamedRegion;
import uk.ac.ed.inf.ilp.data.Order;
import uk.ac.ed.inf.ilp.data.Restaurant;
import uk.ac.ed.inf.path.FlightPath;

import java.io.*;
import java.net.URL;
import java.util.*;

/**
 * The class is used for the interaction with the RestService.
 * @create 2023-10-20-5:48
 */
public class RestService {
	public RestService(){

	}
	/**
	 * Get access to the REST service.
	 * @param API_URL the URL
	 * @return the Json element from the rest service
	 */
	public Object accessRestService(String API_URL, String baseUrl ) {
		// Check whether the base url provided is without the chara "/".
		if (baseUrl.endsWith("/") == false){
			baseUrl += "/";
		}

		// Check whether the base url provided is valid.
		try {
			var temp = new URL(baseUrl);
		} catch (Exception x) {
			System.err.println("The URL is invalid: " + x);
			System.exit(2);
		}

		// Create the new ObjectMapper object.
		ObjectMapper mapper = new ObjectMapper();

		// The JavaTimeModule is a module in Jackson library that supports java.time types.
		// This line registers the JavaTimeModule with the ObjectMapper.
		mapper.registerModule(new JavaTimeModule());

		// Initialize the object which stores the data from the rest service.
		Object v = null;

		/*
		for the restaurants
		 */
		if(API_URL.equals("restaurants")){
			try {
				// Read the value.
				v = mapper.readValue(new URL(baseUrl + API_URL), Restaurant[].class);
			} catch (IOException e) {
				System.err.println("The link is invalid, check the base URL please.");
				throw new RuntimeException(e);
			}
			/*
			for the orders
			 */
		}else if(API_URL.contains("orders")){
			try {
				// Read the value.
				v = mapper.readValue(new URL(baseUrl + API_URL), Order[].class);
			} catch (IOException e) {
				System.err.println("The link is invalid, check the base URL please.");
				throw new RuntimeException(e);
			}
			/*
			for the central area
			 */
		}else if(API_URL.equals("centralArea")){
			try {
				// Read the value.
				v = mapper.readValue(new URL(baseUrl + API_URL), NamedRegion.class);
			} catch (IOException e) {
				System.err.println("The link is invalid, check the base URL please.");
				throw new RuntimeException(e);
			}
			/*
			for the no-fly zones
			 */
		}else if(API_URL.equals("noFlyZones")){
			try {
				// Read the value.
				v = mapper.readValue(new URL(baseUrl + API_URL), NamedRegion[].class);
			} catch (IOException e) {
				System.err.println("The link is invalid, check the base URL please.");
				throw new RuntimeException(e);
			}
		}else{
			System.err.println("The API_URL is wrong!");
		}

		return v;
	}

	/**
	 * Write the orders object into JSON array.
	 * @param orders the valid orders object
	 * @param dateString the date of the order
	 */
	public void WriteToJson(ArrayList<Order> orders, String dateString){
		// Create the ObjectMapper object.
		ObjectMapper objectMapper = new ObjectMapper();

		// Create the SimpleModule object.
		SimpleModule simpleModule = new SimpleModule();

		// Add the custom serializer.
		simpleModule.addSerializer(Order.class, new OrderCustomSerializer());

		// Register a module with the ObjectMapper.
		objectMapper.registerModule(simpleModule);

		try {
			objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File("resultfiles/deliveries-"+dateString+".json"),orders);
			System.out.println("Delivery files are generated successfully...");
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 *  Generate the flightpath of the order.
	 * @param flightPaths the flight path of one destination
	 * @param dateString the date of the order
	 */
	public void WriteToJsonLng(ArrayList<FlightPath> flightPaths, String dateString) {
		// Create the ObjectMapper object.
		ObjectMapper objectMapper = new ObjectMapper();

		// Create the SimpleModule object.
		SimpleModule simpleModule = new SimpleModule();

		// Add the custom serializer.
		simpleModule.addSerializer(FlightPath.class, new FlightpathCustomSerializer());

		// Register a module with the ObjectMapper.
		objectMapper.registerModule(simpleModule);

		try {
			objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File("resultfiles/flightpath-"+dateString+".json"),flightPaths);
			System.out.println("Flightpath files are generated successfully...");
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Generate the Geojson file of the flightpath of the drone
	 * @param arrayLists the flightpath of the drone
	 * @param dateString the date of the order
	 */
	public void writeToGeoJson(ArrayList<ArrayList> arrayLists,String dateString){
		// Create the Map object.
		Map<String, Object> featureCollection = new HashMap<>();

		// The FeatureCollection is added.
		featureCollection.put("type", "FeatureCollection");

		// Create a list of features.
		List<Map<String, Object>> features = new ArrayList<>();

		// Iterate over the arrayLists to create individual feature of the flightpath of an order.
		for (int i = 0; i < arrayLists.size(); i++) {
			// The keys in the map will represent the feature properties and the values will represent the feature values.
			Map<String, Object> feature = new HashMap<>();

			// Put the Feature type into the feature.
			feature.put("type", "Feature");

			// The keys in the map will represent the geometry properties and the values will represent the geometry values.
			Map<String, Object> geometry = new HashMap<>();

			// Put the LineString type into the geometry.
			geometry.put("type", "LineString");

			// Get the coordinates of the points contributing to the flightpath.
			ArrayList<LngLat> lngLats = arrayLists.get(i);

			// Create a 2D array to store the data.
			double[][] array = new double[lngLats.size()][2];

			// Put the coordinates of the point into the 2D array.
			for (int j = 0; j < lngLats.size(); j++) {
				array[j][0] = lngLats.get(j).lng();
				array[j][1] = lngLats.get(j).lat();
			}

			// Make the 2D array to be the coordinates.
			geometry.put("coordinates", array);

			// Put the geometry into the feature.
			feature.put("geometry", geometry);

			// The keys in the map will represent the property names and the values will represent the property values.
			Map<String, Object> properties = new HashMap<>();

			// Put the properties into the feature.
			feature.put("properties", properties);

			// Add the feature into the features.
			features.add(feature);
		}
		// Add the features into the featureCollection.
		featureCollection.put("features", features);
		// Create the ObjectMapper object.
		ObjectMapper mapper = new ObjectMapper();
		try {
			// Write the value into the file.
			mapper.writerWithDefaultPrettyPrinter().writeValue(new File("resultfiles/drone-"+dateString+".geojson"), featureCollection);
			System.out.println("Drone files are generated successfully...");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

