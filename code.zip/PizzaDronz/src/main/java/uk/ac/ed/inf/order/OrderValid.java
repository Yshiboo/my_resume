package uk.ac.ed.inf.order;

import uk.ac.ed.inf.ilp.constant.OrderStatus;
import uk.ac.ed.inf.ilp.constant.OrderValidationCode;
import uk.ac.ed.inf.ilp.data.CreditCardInformation;
import uk.ac.ed.inf.ilp.data.Order;
import uk.ac.ed.inf.ilp.data.Pizza;
import uk.ac.ed.inf.ilp.data.Restaurant;
import uk.ac.ed.inf.ilp.interfaces.OrderValidation;
import uk.ac.ed.inf.ilp.constant.SystemConstants;

import java.time.DateTimeException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * This file is used implement the OrderValidation interface and then provide methods to validate the orders.
 * @create 2023-09-29-1:41
 */
public class OrderValid implements OrderValidation {
	Restaurant restaurant;
	@Override
	public Order validateOrder(Order orderToValidate, Restaurant[] definedRestaurants) {
		// Verify that the provided order isn't null
		if(orderToValidate==null){
			throw new IllegalArgumentException("The order is null");
		}

		// Get the orderDate
		LocalDate orderDate = orderToValidate.getOrderDate();

		//Get the order number.
		String orderNo = orderToValidate.getOrderNo();

		// First assume that the status is invalid
		orderToValidate.setOrderStatus(OrderStatus.INVALID);

		// Get the information of the credit card
		CreditCardInformation creditCardInformation = orderToValidate.getCreditCardInformation();

		//Check whether the credit card is valid
		if (creditCardInformation == null) {
			throw new IllegalArgumentException("Card information is lost.");
		}

		//Check the credit card

		// Get the number of credit card
		String creditCardNumber = creditCardInformation.getCreditCardNumber();
		// Get the expiry date of credit card
		String creditCardExpiry = creditCardInformation.getCreditCardExpiry();
		// Get cvv
		String cvv = creditCardInformation.getCvv();

		/*
		Check whether the provided card number is invalid
		 */
		// Check the length of the card is 16 or that the card number are not all digits
		if(!lengthCheck(16,creditCardNumber) || !digitCheck(creditCardNumber)){
			orderToValidate.setOrderValidationCode(OrderValidationCode.CARD_NUMBER_INVALID);
			return orderToValidate;
		}

		/*
		Check whether the card is expired
		 */
		// The card is expired.
		if(expiredCard(creditCardExpiry,orderDate,orderNo)){
			orderToValidate.setOrderValidationCode(OrderValidationCode.EXPIRY_DATE_INVALID);
			return orderToValidate;
		}

		/*
		Check whether the cvv is valid.
		 */
		// Check whether the cvv is digital and the length of cvv is three
		if (!lengthCheck(3,cvv) || !digitCheck(cvv)) {
			orderToValidate.setOrderValidationCode(OrderValidationCode.CVV_INVALID);
			return orderToValidate;
		}

		// Check pizzas on the order

		// Get the ordered pizzas
		Pizza[] pizzas = orderToValidate.getPizzasInOrder();

		// Convert Pizza[] to arraylist so that the elements can be added or removed
		ArrayList<Pizza> pizzaArrayList = new ArrayList<>(Arrays.asList(pizzas));

		// Get the total price
		int priceTotalInPence = orderToValidate.getPriceTotalInPence();
		// Check whether the prize for the ordered pizza in restaurant's menu is equal to that on the order
		boolean prizeInRes = true;
		// Get the restaurants the pizzas ordered from
		int[] NumRestaurant = pizzaRes(pizzas, definedRestaurants, pizzaArrayList,prizeInRes);

		/*
		 Check whether the total price in pence is correct
		 */
		// If the total price in pence is incorrect or if the prize of the pizza on the order is not equal to the prize on the restaurant's menu
		if(priceCorrect(pizzas,priceTotalInPence) || !prizeInRes){
			orderToValidate.setOrderValidationCode(OrderValidationCode.TOTAL_INCORRECT);
			return orderToValidate;
		}

		/*
		Check there is no pizza not defined.
		 */
		// Check whether there is still pizza left
		if(pizzaArrayList.size() != 0){
			orderToValidate.setOrderValidationCode(OrderValidationCode.PIZZA_NOT_DEFINED);
			return orderToValidate;
		}

		/*
		Check whether exceed the maximum number of pizzas to be ordered
		 */
		if (pizzas.length >= SystemConstants.MAX_PIZZAS_PER_ORDER) {
			orderToValidate.setOrderValidationCode(OrderValidationCode.MAX_PIZZA_COUNT_EXCEEDED);
			return orderToValidate;
		}

		/*
		Check whether pizzas ordered are from multiple restaurants
		 */
		boolean checkEqual = Arrays.stream(NumRestaurant).distinct().count() == 1;
		// If the indexes of the restaurants are not the same
		if(!checkEqual){
			orderToValidate.setOrderValidationCode(OrderValidationCode.PIZZA_FROM_MULTIPLE_RESTAURANTS);
			return orderToValidate;
		}

		// Check the restaurant

		// Set the restaurant
		restaurant = definedRestaurants[NumRestaurant[0]];
		//LocalDate currentDate = LocalDate.now();
		boolean resIsOpen = openDay(orderDate, restaurant);

		/*
		Check whether the restaurant is closed
		 */
		// If today is not the open day
		if(!resIsOpen){
			orderToValidate.setOrderValidationCode(OrderValidationCode.RESTAURANT_CLOSED);
			return orderToValidate;
		}

		// If there is no defined error
		orderToValidate.setOrderValidationCode(OrderValidationCode.NO_ERROR);
		// Set the status of the order
		orderToValidate.setOrderStatus(OrderStatus.VALID_BUT_NOT_DELIVERED);

		// Return the order
		return orderToValidate;
	}

	/**
	 * Check whether the length of the number is as required
	 * @param len the required length
	 * @param num the card number or the cvv
	 * @return true if the length is as required
	 */
	private boolean lengthCheck(int len, String num){
		// Compare the length
		return num.length() == len;
	}

	/**
	 *  Check whether the string is consisted of all natural numbers
	 * @param num the string
	 * @return true if it is consisted of the natural numbers
	 */
	private boolean digitCheck(String num){
		// Check whether the String matches the natural numbers
		return num.matches("\\d+");
	}

	/**
	 *  Compare the expiration date of the credit card with today's date to see if the card has expired
	 * @param creditCardExpiry the expiry date of the card
	 * @param orderDate the date of the order placed
	 * @return true if the card is expired
	 */
	private boolean expiredCard(String creditCardExpiry, LocalDate orderDate,String orderNo){
		// The format of the date
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yy");
		// Convert the expiry date from String into the YearMonth
		YearMonth expiry;
		try{
			expiry = YearMonth.parse(creditCardExpiry, formatter);
		}catch (DateTimeException e){
			System.out.println(orderNo +  ": The input about the expiry of the credit card is illegal which should be MM/yy");
			return true;
		}
		// Get order date
		YearMonth now = YearMonth.from(orderDate);
		// Check whether the expiry is before today
		boolean expired = expiry.isBefore(now);
		return expired;
	}

	/**
	 *  Compare the total price in pence to the pizzas' price plus the delivery price to check whether it is correct
	 * @param pizzas the ordered pizza
	 * @param total the total price in pence
	 * @return true if the total price in pence is correct
	 */
	private boolean priceCorrect(Pizza[] pizzas, int total){
		// Delivery charge is 1 pound
		int deliveryPrice = SystemConstants.ORDER_CHARGE_IN_PENCE;
		// Total price = delivery price (1 pound) + pizzas' prices
		for (Pizza pizza : pizzas) {
			deliveryPrice += pizza.priceInPence();
		}
		return total != deliveryPrice;
	}

	/**
	 *  Get the index of restaurants the pizzas ordered from
	 * @param pizzas ordered pizzas
	 * @param definedRestaurants existed restaurants
	 * @param pizzaArrayList ordered pizzas
	 * @return the array of the index of restaurants
	 */
	private int[] pizzaRes(Pizza[] pizzas, Restaurant[] definedRestaurants,ArrayList<Pizza> pizzaArrayList,boolean prizeInRes){
		// The menus of restaurants
		Pizza[] menu;
		// To record the number of the restaurant where pizza is ordered
		int[] NumRestaurant = new int[pizzas.length];
		// The index of the pizzaArrayList
		int n = pizzaArrayList.size() - 1;
		outer: //label
		for(int j =0;j<definedRestaurants.length;j++){
			// Get the menu of the restaurant
			menu = definedRestaurants[j].menu();
			// Iterate over the menu
			for (Pizza pizza : menu) {
				// To save time, if all the pizzas are found to belong to a same restaurant, then end for loop
				if (pizzaArrayList.size() == 0) {
					break outer;
				}
				// Iterate over ordered pizzas
				for (int i = pizzaArrayList.size()-1; i >= 0; i--) {
					// Check whether the pizza is in the restaurant's menu by pizza's name
					if (pizza.name().equals(pizzaArrayList.get(i).name())) {

						// Check if the pizza's prize on the order is different from that on the restaurant's menu
						if (pizza.priceInPence() != pizzaArrayList.get(i).priceInPence()) {
							prizeInRes = false;
						}

						// Remove the pizza confirmed on the restaurant
						pizzaArrayList.remove(pizzaArrayList.get(i));

						// Record the index of the restaurant
						NumRestaurant[n] = j;
						// Add the index to record next restaurant
						n--;
						// Maybe someone wants to eat two same pizza so don't break the inner for loop
					}
				}
			}
		}
		return NumRestaurant;
	}

	/**
	 *  Check whether the order date is the same as the day when the restaurant is opening
	 * @param orderDate order date
	 * @param restaurant the target restaurant
	 * @return true if the restaurant is opening
	 */
	private boolean openDay(LocalDate orderDate, Restaurant restaurant){
		// Get the day of the week
		DayOfWeek dayOrder = orderDate.getDayOfWeek();

		// Get the target restaurant's opening days
		DayOfWeek[] dayOfWeeks = restaurant.openingDays();

		// Record whether the restaurant will open
		boolean resOpen = false;
		// Iterate over the target restaurant's opening days
		for (DayOfWeek dayOfWeek : dayOfWeeks) {
			if (dayOfWeek == dayOrder) {
				resOpen = true;
				break;
			}
		}
		return resOpen;
	}
}
