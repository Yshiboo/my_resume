package uk.ac.ed.inf.order;

import uk.ac.ed.inf.restservice.RestService;
import uk.ac.ed.inf.ilp.constant.OrderStatus;
import uk.ac.ed.inf.ilp.data.*;

import java.util.ArrayList;

/**
 * This class is responsible for retrieving orders from the REST service and validating them.
 * @create 2023-10-14-4:01
 */
public class ValidateOrders {
	private String URL;
	private String API_URL;
	private OrderValid orderValidation;
	private ArrayList<Order> allOrders;
	private ArrayList<Order> validOrders;
	private Restaurant[] definedRestaurants;
	RestService restService;
	private ArrayList<Restaurant> validOrderRestaurants;

	public ValidateOrders(String URL){
		this.URL = URL;

		allOrders = new ArrayList<>();
		validOrders = new ArrayList<>();
		validOrderRestaurants = new ArrayList<>();
	}

	public ArrayList<Restaurant> getValidOrderRestaurants() {
		return validOrderRestaurants;
	}
	public ArrayList<Order> getValidOrders() {
		return validOrders;
	}

	public ArrayList<Order> getAllOrders() {
		return allOrders;
	}

	/**
	 * Get all the orders of a specific day.
	 * @param systemDate order date
	 * @return The orders of a day.
	 */
	public Order[] orderForSpecifiedDateFromRS(String systemDate){
		restService = new RestService();
		orderValidation = new OrderValid();

		// Provide the URL.
		API_URL = "restaurants";

		// Get access to the REST service and create a Restaurant array.
		definedRestaurants = (Restaurant[]) restService.accessRestService(API_URL,URL);

		// Provide the URL.
		API_URL = "orders/" + systemDate;

		// Get access to the REST service and create an order array.
		Order[] orders = (Order[]) restService.accessRestService(API_URL,URL);

		return orders;
	}

	/**
	 * Check the validation of order.
	 * @param order the order to be checked
	 */
	public void checkValidation(Order order){
		// Validate the order.
		Order orderValid = orderValidation.validateOrder(order, definedRestaurants);

		// If the order is valid but not delivered.
		if(orderValid.getOrderStatus() == OrderStatus.VALID_BUT_NOT_DELIVERED){
			validOrders.add(orderValid);
			validOrderRestaurants.add(orderValidation.restaurant);
		}

		// Add all the tested orders no matter whether it's valid.
		allOrders.add(orderValid);
	}
}