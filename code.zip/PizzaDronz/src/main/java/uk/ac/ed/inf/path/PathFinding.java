package uk.ac.ed.inf.path;

import uk.ac.ed.inf.restservice.RestService;
import uk.ac.ed.inf.order.ValidateOrders;
import uk.ac.ed.inf.ilp.constant.OrderStatus;
import uk.ac.ed.inf.ilp.constant.SystemConstants;
import uk.ac.ed.inf.ilp.data.*;

import java.awt.geom.Line2D;
import java.util.*;

/**
 * This is to generate the flightpath from AT to the restaurants, using A star algorithm.
 * @create 2023-10-18-19:22
 */
public class PathFinding {
	private String URL;
	private LngLat dest;
	private LngLat start;
	private String API_URL;
	private NamedRegion[] noFly;
	private NamedRegion centralArea;
	private Restaurant targetRestaurant;
	private PriorityQueue<LngLat> pq;
	private ArrayList<Restaurant> validOrderRestaurants;
	private ArrayList<Order> validOrders;
	private ArrayList<LngLat> trip;
	private RestService restService = new RestService();
	private LngLatHandle lngLatHandle = new LngLatHandle();
	private HashMap<LngLat,Double> angleOfPoint = new HashMap<>();
	private double cost = SystemConstants.DRONE_MOVE_DISTANCE;
	private HashMap<LngLat, Double> costTotal = new HashMap<>();


	public PathFinding(ValidateOrders validateOrdersObj, String URL) {
		this.URL = URL;

		validOrderRestaurants = validateOrdersObj.getValidOrderRestaurants();
		validOrders = validateOrdersObj.getValidOrders();
	}

	/**
	 * The start point of the drone.
	 * @return the location of the AT
	 */
	private LngLat start() {
		start = new LngLat(-3.186874, 55.944494);
		return start;
	}

	/**
	 * Find the destination of the drone
	 * @param k The kth order
	 * @return the location of the restaurant
	 */
	private LngLat dest(int k) {
		// Get the restaurant destination
		Restaurant restaurant = validOrderRestaurants.get(k);

		//Get the restaurant location
		dest = restaurant.location();
		return dest;
	}

	/**
	 * Find the target restaurant.
	 * @param k the kth order
	 * @return the corresponding restaurant
	 */
	public Restaurant targetRestaurant(int k){
		// Get the restaurant.
		targetRestaurant = validOrderRestaurants.get(k);

		return targetRestaurant;
	}

	/**
	 * The heuristic function of the point.
	 * @param point the testing point
	 * @return the Euclidean Distance of the point from the destination.
	 */
	private double heuristic(LngLat point) {
		// Get the longitude of the destination point.
		double destLng = dest.lng();

		// Get the latitude of the destination point.
		double destLat = dest.lat();

		// Get the longitude of the testing point.
		double lng = point.lng();

		// Get the latitude of the testing point.
		double lat = point.lat();

		// Return the result of the Euclidean Distance.
		return Math.sqrt(Math.pow(destLng - lng,2)+Math.pow(destLat - lat,2));
	}

	/**
	 * Get the detailed information about no-fly regions from online rest service.
	 */
	private void noFlyRegions() {
		// Provide the URL.
		API_URL = "noFlyZones";

		// Get the no-fly regions.
		noFly = (NamedRegion[]) restService.accessRestService(API_URL,URL);
	}

	/**
	 * Get the detailed information about central area from online rest service.
	 */
	private void centralArea() {
		// Provide the URL.
		API_URL = "centralArea";

		// Get the central area information.
		centralArea = (NamedRegion) restService.accessRestService(API_URL,URL);
	}

	/**
	 *  Determine whether the point is in central area.
	 * @param point the test point
	 * @return true if the point is in the central area and otherwise false.
	 */
	private boolean inCentralArea(LngLat point) {
		// Define a boolean value to record the results.
		boolean inRegion;

		// Determine whether the point is in central area.
		inRegion = lngLatHandle.isInCentralArea(point, centralArea);
		return inRegion;
	}

	/**
	 *  Test whether the nextPoint is in the no-fly region and also the connection between the
	 *  nest nextPoint and the current nextPoint should not in the no-fly region.
	 * @param nextPoint the next nextPoint of the current nextPoint which is tested to decide whether it can be added to the
	 *              priority queue.
	 * @param currentPoint  the current nextPoint which has already polled from the priority queue
	 * @return true if it is in the no-fly region and otherwise false
	 */
	private boolean obstacle(LngLat nextPoint, LngLat currentPoint) {
		// Define a boolean value to record the results.
		boolean inRegion;

		// Iterate over the no-fly regions to test whether the nextPoint in one of the no-fly regions
		// or the segment intersects with one of the no-fly regions.
		for (int i = 0; i < noFly.length; i++) {

			// Whether the nextPoint is in the no-fly regions.
			inRegion = lngLatHandle.isInRegion(nextPoint, noFly[i]);

			// Whether the segment is intersects with no-fly regions.
			boolean lineInNoFly = lineInNoFly(nextPoint, currentPoint, noFly[i]);

			// If either of them are true, then the next nextPoint is not valid and can be seen as in the no-fly regions.
			if(inRegion || lineInNoFly){
				return true;
			}
		}

		return false;
	}

	/**
	 * Test whether the connection between the current nextPoint and the next nextPoint intersects with no-fly regions
	 * @param nextPoint the next point to be tested
	 * @param currentPoint the current nextPoint polled from the priority queue
	 * @param noFlyRegion one of the no-fly regions
	 * @return true if the connection intersects with no-fly regions and otherwise false
	 */
	private boolean lineInNoFly(LngLat nextPoint, LngLat currentPoint, NamedRegion noFlyRegion){
		// Get the boundary of the noFlyRegion
		LngLat[] vertices = noFlyRegion.vertices();

		// Create a segment.
		Line2D line = new Line2D.Double(nextPoint.lng(), nextPoint.lat(), currentPoint.lng(), currentPoint.lat());

		//Iterate over the vertices of the region.
		for(int k = 0;k<vertices.length-1;k++) {

			// Create the segment between the two vertices of the no-fly region.
			Line2D lineRegion = new Line2D.Double(vertices[k].lng(),vertices[k].lat(), vertices[k+1].lng(),vertices[k+1].lat());

			// Get whether the two segments are intersected with each other.
			boolean intersectsLine = lineRegion.intersectsLine(line);

			// If intersect, then return true.
			if(intersectsLine){
				return true;
			}
		}

		return false;
	}

	/**
	 * Get the next point from the current point.
	 * @param currentPosition the current point
	 * @return the next points
	 */
	private LngLat[] nextPositionForCurrent(LngLat currentPosition) {
		// Since there are 16 available move angles.
		LngLat[] nextPoints = new LngLat[16];

		// Create the next point object.
		LngLat nextPosition;

		// Create the boolean value to record whether the next point is in no-fly regions.
		boolean inNoFlyRegions;

		// Create the angle object to record the angle.
		double angle;

		// Test whether the current points is in the central area, so it can be used whether the next point can
		// be in the central area. Since the start point is in the central area, if the parent point is not in the
		// central area, then the next point cannot be in the central area.
		boolean currentInCentralArea = inCentralArea(currentPosition);

		// Iterate over the possible angles.
		for (int i = 0; i < 16; i++) {

			// Assign the value of the angle.
			angle = i * 22.5;

			// Get the next point.
			nextPosition = lngLatHandle.nextPosition(currentPosition, angle);

			// Put it in the nextPoints array.
			nextPoints[i] = nextPosition;

			// If the current is not in the central area,
			if(!currentInCentralArea){

				// then next point should not be in the central area.
				if(inCentralArea(nextPosition)){

					// Make the invalid next point to be null.
					nextPoints[i] = null;
				}
			}

			// If the next point is not null, then test whether it's in no-fly regions.
			if(nextPoints[i]!= null){

				// Test whether the next point is in no-fly regions.
				inNoFlyRegions = obstacle(nextPosition,currentPosition);

				// If the next point is in no-fly regions,
				if (inNoFlyRegions) {

					// mke the invalid next points to be null.
					nextPoints[i] = null;
				}
			}
		}
		return nextPoints;
	}

	/**
	 * Initialise the relevant location. i.e. the restaurant, the central area and the no-fly regions
	 */
	public void initialize() {
		noFlyRegions();
		centralArea();
		start();
	}

	/**
	 * Create a comparator for the priority queue in the a star algorithm.
	 */
	public void comparatorForAlgorithm(){
		// Create the comparator.
		Comparator<LngLat> comparator = (LngLat point1, LngLat point2) -> {

			// Get the accumulated cost from two points.
			Double accumulatedCost1 = costTotal.get(point1);
			Double accumulatedCost2 = costTotal.get(point2);

			// Get the distance from the point to the destination.
			double distance1 = heuristic(point1);
			double distance2 = heuristic(point2);

			// Get the added result.
			double res1 = accumulatedCost1 + distance1;
			double res2 = accumulatedCost2 + distance2;

			// Make the increasing order in the priority queue.
			if (res1 < res2) {
				return -1;
			} else {
				return 1;
			}
		};

		// Initialize the priority queue with the defined comparator.
		pq = new PriorityQueue(comparator);
	}

	/**
	 * Use A star algorithm to find the flight path.
	 * @param k the kth valid order
	 * @return the arraylist of the points consisted of the flightpath
	 */
	public ArrayList<LngLat> aStar(int k) {
		pq.clear();
		costTotal.clear();
		angleOfPoint.clear();

		// Set the destination of the drone for the flight from AT to the order restaurant.
		if(k<validOrderRestaurants.size()){
			dest(k);
		}

		// Create the HashSet for the visited position.
		HashSet<LngLat> visitedSet = new HashSet<>();

		// Create the arraylist for the flightpath.
		ArrayList<LngLat> totalPointsForFlightPath = new ArrayList<>();

		HashMap<LngLat, LngLat> previousOne = new HashMap<>();

		// Record the current point polled from the priority queue.
		LngLat currentPoint;

		// Add the start point in the priority queue.
		pq.add(start);

		// Put the total cost of the start point into the HashMap as a record.
		costTotal.put(start, 0.0);

		// Put the start point and its parent point into the HashMap as a record.
		previousOne.put(start,null);//current point, parent point

		// Record the last point which is close to the target restaurant.
		LngLat pointCloseToRestaurant = null;

		while (!pq.isEmpty()) {
			// Poll the first element in the priority queue with the least cost and delete it in the priority queue.
			currentPoint = pq.poll();

			// If the visited set is not empty, then test whether it contains the current point.
			// If it contains the current point, then just skip the rest of the code to prevent the possible loop.
			// Also, work as the lazy priority queue remove. I didn't update the priority queue.
			if(!visitedSet.isEmpty()){
				if(visitedSet.contains(currentPoint)){
					continue;
				}
			}

			// Add the current point into the visited set.
			visitedSet.add(currentPoint);

			// If the current point is close to the target restaurant,
			if (lngLatHandle.isCloseTo(currentPoint, dest)) {
				// record the current point and exit the while loop.
				pointCloseToRestaurant = currentPoint;
				break;
			}

			// Get all the next points of the current point.
			LngLat[] nextPoints = nextPositionForCurrent(currentPoint);

			// Iterate over the next points.
			for (int i = 0; i < 16; i++) {
				// If the next point is not valid, then just continue the for loop.
				if (nextPoints[i] == null) {
					continue;
				}

				/*
				If the next point is valid,
				 */
				// Get the new cost of the next point which is the cost of the parent cost added with the movement cost.
				double newCost = costTotal.get(currentPoint) + cost;

				// If the node has been added in the priority queue and the new cost is greater, then just skip the rest of the code in the for loop.
				// Skip means not updating the information.
				if (costTotal.containsKey(nextPoints[i]) ) {
					if(newCost >= costTotal.get(nextPoints[i])){
						continue;
					}
				}

				// If the point has been added, the new value will replace with the old value.
				// If the point has not been added, this will put the element pair in the HashMap.

				// Put the smallest movement cost and the point in the HashMap.
				costTotal.put(nextPoints[i], newCost);

				// Get the angle.
				double angle = i * 22.5;

				// Put the angle and the point in the HashMap.
				angleOfPoint.put(nextPoints[i],angle);

				// Put the current point and the parent point into the HashMap.
				previousOne.put(nextPoints[i], currentPoint);


				// Instead of removing the existed element in the priority queue and replacing it with the less cost one,
				// just add the current point into the priority queue. The old point will be lazy deleted at the beginning
				// of the while loop which is just to skip the rest of the code.
				pq.add(nextPoints[i]);
			}
		}

		// Get the parent point of the pointCloseToRestaurant.
		LngLat pathPoint = previousOne.get(pointCloseToRestaurant);

		// Add the points into the totalPointsForFlightPath arraylist.
		totalPointsForFlightPath.add(pointCloseToRestaurant);
		totalPointsForFlightPath.add(pathPoint);

		// Use the while loop to find the parent point until it is the start.
		while (pathPoint != start){
			// Get the parent point.
			pathPoint = previousOne.get(pathPoint);
			// Add the parent point into the totalPointsForFlightPath arraylist.
			totalPointsForFlightPath.add(pathPoint);
		}

		// Get the point when the drone needs to hover at the start point.
		LngLat hoverPointAtStart = lngLatHandle.nextPosition(start,999);

		// First get the trip with the same size of the totalPointsForFlightPath from the target restaurant to the start point.
		trip = new ArrayList<>(totalPointsForFlightPath);
		Collections.reverse(trip);

		// Add the hover point at the end of the return trip.
		totalPointsForFlightPath.add(hoverPointAtStart);

		// Add the return trip to form the flightpath points of the drone.
		trip.addAll(totalPointsForFlightPath);

		// Set the corresponding order status to be delivered.
		validOrders.get(k).setOrderStatus(OrderStatus.DELIVERED);
		return trip;
	}

	/**
	 * Set all the LngLat points to be FlightPath points for the output file flightpath.
	 * @param k the kth valid order
	 * @return the FlightPath array
	 */
	public FlightPath[] flightPaths(int k){
		// Get the order number.
		String orderNo = validOrders.get(k).getOrderNo();

		// Create the flightpath array.
		FlightPath[] flightPaths = new FlightPath[trip.size()-1];

		// Use angle to record the corresponding angle.
		double angle;

		// Iterate over the flightpath.
		for (int p = 0;p<flightPaths.length;p++) {

			// Create the flightpath object.
			flightPaths[p] = new FlightPath();

			/*Set the attributes of the flightpath.*/
			flightPaths[p].setOrderNo(orderNo);
			flightPaths[p].setFromLongitude(trip.get(p).lng());
			flightPaths[p].setFromLatitude(trip.get(p).lat());

			// For the trip from start point to the restaurant, the angle is equal to the recorded angle.
			if(p< flightPaths.length/2-1){
				angle = angleOfPoint.get(trip.get(p+1));
				flightPaths[p].setAngle(angle);

				// At the target restaurant, the drone needs to hover.
			}else if(trip.get(p) == trip.get(p + 1) && p == flightPaths.length/2-1){
				angle = 999.0;
				flightPaths[p].setAngle(angle);

				// For the trip from the restaurant back to the start point, the angle is the supplementary angle.
			}else if(p < flightPaths.length-1) {
				angle = (angleOfPoint.get(trip.get(p)) + 180.0) % 360.0;
				flightPaths[p].setAngle(angle);

				// When back to the start point, the drone needs to hover.
			}else if(p == flightPaths.length-1){
				angle = 999.0;
				flightPaths[p].setAngle(angle);
			}
			flightPaths[p].setToLongitude(trip.get(p+1).lng());
			flightPaths[p].setToLatitude(trip.get(p+1).lat());
		}
		return flightPaths;
	}
}
